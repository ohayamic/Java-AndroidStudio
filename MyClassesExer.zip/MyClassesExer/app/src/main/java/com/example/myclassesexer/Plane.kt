package com.example.myclassesexer

class Plane(make:String, model:String, year:Int, weight:Int):Vehicle(make, model, year, weight) {

    var isDriving: Boolean = false

    fun flying(): Boolean{
        this.isDriving = true
        if (this.NeedsMaintenance == true){
            println("You can no longer fly this plane")
            return false
        }
        return true
    }

    fun landing(){
        this.isDriving = false
        this.TripsSinceMaintenance ++
        if(this.TripsSinceMaintenance > 100){
            this.NeedsMaintenance = true
        }
    }
    fun repair(){
        this.NeedsMaintenance = false
        this.TripsSinceMaintenance = 0
    }


}